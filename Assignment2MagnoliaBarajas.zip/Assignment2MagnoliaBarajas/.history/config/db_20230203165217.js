module.exports =
{
"URI":"mongodb://local"
}