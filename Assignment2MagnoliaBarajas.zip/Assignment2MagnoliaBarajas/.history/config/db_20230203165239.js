module.exports =
{
"URI":"mongodb://localhost/book_store"
}