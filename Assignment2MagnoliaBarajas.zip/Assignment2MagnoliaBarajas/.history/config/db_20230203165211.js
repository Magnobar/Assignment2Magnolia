module.exports =
{
"URI":"mongodb:"
}