module.exports =
{
"URI":"mongodb://"
}