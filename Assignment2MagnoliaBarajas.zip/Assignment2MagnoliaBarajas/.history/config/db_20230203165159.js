module.exports =
{
"URI"
}