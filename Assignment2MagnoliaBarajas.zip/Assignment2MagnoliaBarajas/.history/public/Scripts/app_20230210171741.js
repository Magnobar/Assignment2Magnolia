(function () {
    function start() {
        console.log("App Started....");
        let deleteButton = document.querySelectorAll('.btn-danger')
        for(button of deleteButton)
    }
    window.addEventListener("load", start);
})();