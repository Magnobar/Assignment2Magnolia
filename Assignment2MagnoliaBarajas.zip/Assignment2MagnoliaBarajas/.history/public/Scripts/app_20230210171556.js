(function () {
    function start() {
        console.log("App Started....");
        let deleteButton
    }
    window.addEventListener("load", start);
})();