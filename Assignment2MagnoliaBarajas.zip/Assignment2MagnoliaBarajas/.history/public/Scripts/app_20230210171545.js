(function () {
    function start() {
        console.log("App Started....");
        
    }
    window.addEventListener("load", start);
})();