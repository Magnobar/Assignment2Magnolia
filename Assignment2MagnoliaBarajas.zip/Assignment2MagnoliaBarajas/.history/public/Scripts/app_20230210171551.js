(function () {
    function start() {
        console.log("App Started....");
        let delete
    }
    window.addEventListener("load", start);
})();